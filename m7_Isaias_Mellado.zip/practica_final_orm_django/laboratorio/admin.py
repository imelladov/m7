from django.contrib import admin
from .models import Laboratorio, DirectorGeneral, Producto

class LaboratorioAdmin(admin.ModelAdmin):
    list_display = ('id', 'nombre')  # Mostrar ID y Nombre
    ordering = ('id',)

class DirectorGeneralAdmin(admin.ModelAdmin):
    list_display = ('id', 'nombre', 'laboratorio')  # Muestra ID, Nombre y Laboratorio
    ordering = ('id',)  # Ordena por ID
    search_fields = ('nombre', 'laboratorio__nombre')  # Agrega barra de búsqueda

class ProductoAdmin(admin.ModelAdmin):
    list_display = ('id', 'nombre', 'laboratorio', 'f_fabricacion', 'p_costo', 'p_venta')  # Mostrar columnas
    ordering = ('id',)  # Ordenar por ID
    list_filter = ('laboratorio', 'nombre')  # Agregar filtros por laboratorio y nombre
    search_fields = ('nombre', 'laboratorio__nombre')  # Agregar barra de búsqueda)

admin.site.register(Laboratorio, LaboratorioAdmin)
admin.site.register(DirectorGeneral, DirectorGeneralAdmin)
admin.site.register(Producto, ProductoAdmin)
