from django.test import TestCase
from django.urls import reverse
from .models import Laboratorio

class LaboratorioTestCase(TestCase):

    @classmethod
    def setUpTestData(cls):
        """ Configuración inicial: Crear un laboratorio para pruebas """
        cls.laboratorio = Laboratorio.objects.create(
            nombre="LabTest",
            ciudad="Santiago",
            pais="Chile"
        )

    def test_laboratorio_datos(self):
        """ Verifica que los datos en la base de datos coincidan con los creados en setUpTestData """
        lab = Laboratorio.objects.get(id=self.laboratorio.id)
        self.assertEqual(lab.nombre, "LabTest")
        self.assertEqual(lab.ciudad, "Santiago")
        self.assertEqual(lab.pais, "Chile")

    def test_url_listar_laboratorios(self):
        """ Verifica que la URL de listar laboratorios responde con HTTP 200 """
        response = self.client.get(reverse('listar_laboratorios'))
        self.assertEqual(response.status_code, 200)

    def test_url_crear_laboratorio(self):
        """ Prueba que la página de creación devuelve HTTP 200 """
        response = self.client.get(reverse('crear_laboratorio'))
        self.assertEqual(response.status_code, 200)

    def test_listar_laboratorios_usa_plantilla_correcta(self):
        """ Verifica que la vista de listar laboratorios usa la plantilla correcta """
        response = self.client.get(reverse('listar_laboratorios'))
        self.assertTemplateUsed(response, 'laboratorio/listar.html')

    def test_listar_laboratorios_html_contenido(self):
        """ Verifica que la página de listar laboratorios contiene el HTML esperado """
        response = self.client.get(reverse('listar_laboratorios'))
    
        # Verifica solo que el texto "Información de Laboratorios" esté presente
        self.assertContains(response, "Información de Laboratorios")
        self.assertContains(response, "LabTest")