from django.urls import path
from .views import listar_laboratorios, crear_laboratorio, editar_laboratorio, eliminar_laboratorio

urlpatterns = [
    path('', listar_laboratorios, name='listar_laboratorios'),
    path('crear/', crear_laboratorio, name='crear_laboratorio'),  
    path('editar/<int:id>/', editar_laboratorio, name='editar_laboratorio'),
    path('eliminar/<int:id>/', eliminar_laboratorio, name='eliminar_laboratorio'),
]
